<?php
/**
 * Created by ra on 6/13/2015.
 */

//ads
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             'http://demo_content.tagdiv.com/Newspaper_6/art_creek/logo-mobile.png');
td_demo_media::add_image_to_media_gallery('td_custom_ad_1',             "http://demo_content.tagdiv.com/Newspaper_6/art_creek/td-custom-ad-1.png");
td_demo_media::add_image_to_media_gallery('td_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/art_creek/td-sidebar-ad.png");
td_demo_media::add_image_to_media_gallery('td_dark_bg_1',               "http://demo_content.tagdiv.com/Newspaper_6/art_creek/td-dark-bg-1.jpg");