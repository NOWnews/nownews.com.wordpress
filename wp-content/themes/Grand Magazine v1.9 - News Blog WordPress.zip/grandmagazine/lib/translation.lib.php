<?php
load_theme_textdomain( 'grandmagazine', get_template_directory().'/languages' );
?>