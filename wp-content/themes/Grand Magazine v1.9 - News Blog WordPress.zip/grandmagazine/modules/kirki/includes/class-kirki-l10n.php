<?php
/**
 * Internationalization helper.
 *
 * @package     Kirki
 * @category    Core
 * @author      Aristeides Stathopoulos
 * @copyright   Copyright (c) 2016, Aristeides Stathopoulos
 * @license     http://opensource.org/licenses/https://opensource.org/licenses/MIT
 * @since       1.0
 */

if ( ! class_exists( 'Kirki_l10n' ) ) {

	/**
	 * Handles translations
	 */
	class Kirki_l10n {

		/**
		 * The plugin textdomain
		 *
		 * @access protected
		 * @var string
		 */
		protected $textdomain = 'kirki';

		/**
		 * The class constructor.
		 * Adds actions & filters to handle the rest of the methods.
		 *
		 * @access public
		 */
		public function __construct() {

			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );

		}

		/**
		 * Load the plugin textdomain
		 *
		 * @access public
		 */
		public function load_textdomain() {

			if ( null !== $this->get_path() ) {
				load_textdomain( $this->textdomain, $this->get_path() );
			}
			load_plugin_textdomain( $this->textdomain, false, Kirki::$path . '/languages' );

		}

		/**
		 * Gets the path to a translation file.
		 *
		 * @access protected
		 * @return string Absolute path to the translation file.
		 */
		protected function get_path() {
			$path_found = false;
			$found_path = null;
			foreach ( $this->get_paths() as $path ) {
				if ( $path_found ) {
					continue;
				}
				$path = wp_normalize_path( $path );
				if ( file_exists( $path ) ) {
					$path_found = true;
					$found_path = $path;
				}
			}

			return $found_path;

		}

		/**
		 * Returns an array of paths where translation files may be located.
		 *
		 * @access protected
		 * @return array
		 */
		protected function get_paths() {

			return array(
				WP_LANG_DIR . '/' . $this->textdomain . '-' . get_locale() . '.mo',
				Kirki::$path . '/languages/' . $this->textdomain . '-' . get_locale() . '.mo',
			);

		}

		/**
		 * Shortcut method to get the translation strings
		 *
		 * @static
		 * @access public
		 * @param string $config_id The config ID. See Kirki_Config.
		 * @return array
		 */
		public static function get_strings( $config_id = 'global' ) {

			$translation_strings = array(
				'background-color'      => esc_attr__( 'Background Color', 'grandmagazine' ),
				'background-image'      => esc_attr__( 'Background Image', 'grandmagazine' ),
				'no-repeat'             => esc_attr__( 'No Repeat', 'grandmagazine' ),
				'repeat-all'            => esc_attr__( 'Repeat All', 'grandmagazine' ),
				'repeat-x'              => esc_attr__( 'Repeat Horizontally', 'grandmagazine' ),
				'repeat-y'              => esc_attr__( 'Repeat Vertically', 'grandmagazine' ),
				'inherit'               => esc_attr__( 'Inherit', 'grandmagazine' ),
				'background-repeat'     => esc_attr__( 'Background Repeat', 'grandmagazine' ),
				'cover'                 => esc_attr__( 'Cover', 'grandmagazine' ),
				'contain'               => esc_attr__( 'Contain', 'grandmagazine' ),
				'background-size'       => esc_attr__( 'Background Size', 'grandmagazine' ),
				'fixed'                 => esc_attr__( 'Fixed', 'grandmagazine' ),
				'scroll'                => esc_attr__( 'Scroll', 'grandmagazine' ),
				'background-attachment' => esc_attr__( 'Background Attachment', 'grandmagazine' ),
				'left-top'              => esc_attr__( 'Left Top', 'grandmagazine' ),
				'left-center'           => esc_attr__( 'Left Center', 'grandmagazine' ),
				'left-bottom'           => esc_attr__( 'Left Bottom', 'grandmagazine' ),
				'right-top'             => esc_attr__( 'Right Top', 'grandmagazine' ),
				'right-center'          => esc_attr__( 'Right Center', 'grandmagazine' ),
				'right-bottom'          => esc_attr__( 'Right Bottom', 'grandmagazine' ),
				'center-top'            => esc_attr__( 'Center Top', 'grandmagazine' ),
				'center-center'         => esc_attr__( 'Center Center', 'grandmagazine' ),
				'center-bottom'         => esc_attr__( 'Center Bottom', 'grandmagazine' ),
				'background-position'   => esc_attr__( 'Background Position', 'grandmagazine' ),
				'background-opacity'    => esc_attr__( 'Background Opacity', 'grandmagazine' ),
				'on'                    => esc_attr__( 'ON', 'grandmagazine' ),
				'off'                   => esc_attr__( 'OFF', 'grandmagazine' ),
				'all'                   => esc_attr__( 'All', 'grandmagazine' ),
				'cyrillic'              => esc_attr__( 'Cyrillic', 'grandmagazine' ),
				'cyrillic-ext'          => esc_attr__( 'Cyrillic Extended', 'grandmagazine' ),
				'devanagari'            => esc_attr__( 'Devanagari', 'grandmagazine' ),
				'greek'                 => esc_attr__( 'Greek', 'grandmagazine' ),
				'greek-ext'             => esc_attr__( 'Greek Extended', 'grandmagazine' ),
				'khmer'                 => esc_attr__( 'Khmer', 'grandmagazine' ),
				'latin'                 => esc_attr__( 'Latin', 'grandmagazine' ),
				'latin-ext'             => esc_attr__( 'Latin Extended', 'grandmagazine' ),
				'vietnamese'            => esc_attr__( 'Vietnamese', 'grandmagazine' ),
				'hebrew'                => esc_attr__( 'Hebrew', 'grandmagazine' ),
				'arabic'                => esc_attr__( 'Arabic', 'grandmagazine' ),
				'bengali'               => esc_attr__( 'Bengali', 'grandmagazine' ),
				'gujarati'              => esc_attr__( 'Gujarati', 'grandmagazine' ),
				'tamil'                 => esc_attr__( 'Tamil', 'grandmagazine' ),
				'telugu'                => esc_attr__( 'Telugu', 'grandmagazine' ),
				'thai'                  => esc_attr__( 'Thai', 'grandmagazine' ),
				'serif'                 => _x( 'Serif', 'font style', 'grandmagazine' ),
				'sans-serif'            => _x( 'Sans Serif', 'font style', 'grandmagazine' ),
				'monospace'             => _x( 'Monospace', 'font style', 'grandmagazine' ),
				'font-family'           => esc_attr__( 'Font Family', 'grandmagazine' ),
				'font-size'             => esc_attr__( 'Font Size', 'grandmagazine' ),
				'font-weight'           => esc_attr__( 'Font Weight', 'grandmagazine' ),
				'line-height'           => esc_attr__( 'Line Height', 'grandmagazine' ),
				'font-style'            => esc_attr__( 'Font Style', 'grandmagazine' ),
				'letter-spacing'        => esc_attr__( 'Letter Spacing', 'grandmagazine' ),
				'top'                   => esc_attr__( 'Top', 'grandmagazine' ),
				'bottom'                => esc_attr__( 'Bottom', 'grandmagazine' ),
				'left'                  => esc_attr__( 'Left', 'grandmagazine' ),
				'right'                 => esc_attr__( 'Right', 'grandmagazine' ),
				'center'                => esc_attr__( 'Center', 'grandmagazine' ),
				'justify'               => esc_attr__( 'Justify', 'grandmagazine' ),
				'color'                 => esc_attr__( 'Color', 'grandmagazine' ),
				'add-image'             => esc_attr__( 'Add Image', 'grandmagazine' ),
				'change-image'          => esc_attr__( 'Change Image', 'grandmagazine' ),
				'no-image-selected'     => esc_attr__( 'No Image Selected', 'grandmagazine' ),
				'add-file'              => esc_attr__( 'Add File', 'grandmagazine' ),
				'change-file'           => esc_attr__( 'Change File', 'grandmagazine' ),
				'no-file-selected'      => esc_attr__( 'No File Selected', 'grandmagazine' ),
				'remove'                => esc_attr__( 'Remove', 'grandmagazine' ),
				'select-font-family'    => esc_attr__( 'Select a font-family', 'grandmagazine' ),
				'variant'               => esc_attr__( 'Variant', 'grandmagazine' ),
				'subsets'               => esc_attr__( 'Subset', 'grandmagazine' ),
				'size'                  => esc_attr__( 'Size', 'grandmagazine' ),
				'height'                => esc_attr__( 'Height', 'grandmagazine' ),
				'spacing'               => esc_attr__( 'Spacing', 'grandmagazine' ),
				'ultra-light'           => esc_attr__( 'Ultra-Light 100', 'grandmagazine' ),
				'ultra-light-italic'    => esc_attr__( 'Ultra-Light 100 Italic', 'grandmagazine' ),
				'light'                 => esc_attr__( 'Light 200', 'grandmagazine' ),
				'light-italic'          => esc_attr__( 'Light 200 Italic', 'grandmagazine' ),
				'book'                  => esc_attr__( 'Book 300', 'grandmagazine' ),
				'book-italic'           => esc_attr__( 'Book 300 Italic', 'grandmagazine' ),
				'regular'               => esc_attr__( 'Normal 400', 'grandmagazine' ),
				'italic'                => esc_attr__( 'Normal 400 Italic', 'grandmagazine' ),
				'medium'                => esc_attr__( 'Medium 500', 'grandmagazine' ),
				'medium-italic'         => esc_attr__( 'Medium 500 Italic', 'grandmagazine' ),
				'semi-bold'             => esc_attr__( 'Semi-Bold 600', 'grandmagazine' ),
				'semi-bold-italic'      => esc_attr__( 'Semi-Bold 600 Italic', 'grandmagazine' ),
				'bold'                  => esc_attr__( 'Bold 700', 'grandmagazine' ),
				'bold-italic'           => esc_attr__( 'Bold 700 Italic', 'grandmagazine' ),
				'extra-bold'            => esc_attr__( 'Extra-Bold 800', 'grandmagazine' ),
				'extra-bold-italic'     => esc_attr__( 'Extra-Bold 800 Italic', 'grandmagazine' ),
				'ultra-bold'            => esc_attr__( 'Ultra-Bold 900', 'grandmagazine' ),
				'ultra-bold-italic'     => esc_attr__( 'Ultra-Bold 900 Italic', 'grandmagazine' ),
				'invalid-value'         => esc_attr__( 'Invalid Value', 'grandmagazine' ),
				'add-new'           	=> esc_attr__( 'Add new', 'grandmagazine' ),
				'row'           		=> esc_attr__( 'row', 'grandmagazine' ),
				'limit-rows'            => esc_attr__( 'Limit: %s rows', 'grandmagazine' ),
				'open-section'          => esc_attr__( 'Press return or enter to open this section', 'grandmagazine' ),
				'back'                  => esc_attr__( 'Back', 'grandmagazine' ),
				'reset-with-icon'       => sprintf( esc_attr__( '%s Reset', 'grandmagazine' ), '<span class="dashicons dashicons-image-rotate"></span>' ),
				'text-align'            => esc_attr__( 'Text Align', 'grandmagazine' ),
				'text-transform'        => esc_attr__( 'Text Transform', 'grandmagazine' ),
				'none'                  => esc_attr__( 'None', 'grandmagazine' ),
				'capitalize'            => esc_attr__( 'Capitalize', 'grandmagazine' ),
				'uppercase'             => esc_attr__( 'Uppercase', 'grandmagazine' ),
				'lowercase'             => esc_attr__( 'Lowercase', 'grandmagazine' ),
				'initial'               => esc_attr__( 'Initial', 'grandmagazine' ),
				'select-page'           => esc_attr__( 'Select a Page', 'grandmagazine' ),
				'open-editor'           => esc_attr__( 'Open Editor', 'grandmagazine' ),
				'close-editor'          => esc_attr__( 'Close Editor', 'grandmagazine' ),
				'switch-editor'         => esc_attr__( 'Switch Editor', 'grandmagazine' ),
				'hex-value'             => esc_attr__( 'Hex Value', 'grandmagazine' ),
			);

			// Apply global changes from the kirki/config filter.
			// This is generally to be avoided.
			// It is ONLY provided here for backwards-compatibility reasons.
			// Please use the kirki/{$config_id}/l10n filter instead.
			$config = apply_filters( 'kirki/config', array() );
			if ( isset( $config['i18n'] ) ) {
				$translation_strings = wp_parse_args( $config['i18n'], $translation_strings );
			}

			// Apply l10n changes using the kirki/{$config_id}/l10n filter.
			return apply_filters( 'kirki/' . $config_id . '/l10n', $translation_strings );

		}
	}
}
