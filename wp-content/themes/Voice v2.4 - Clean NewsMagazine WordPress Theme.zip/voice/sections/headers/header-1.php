<div class="container header-1-wrapper header-main-area">	
		<?php get_template_part( 'sections/headers/logo'); ?>
</div>

<div class="header-bottom-wrapper">
	<div class="container">
		<?php get_template_part( 'sections/headers/navigation'); ?>
	</div>
</div>